<?php

if(!empty($_POST['user']) && !empty($_POST['pass']) && !empty($_POST['dominio']))
{
$user  = $_POST['user'] . '@' . $_POST['dominio'];
$ldaprdn  = $_POST['user'];
$ldappass = $_POST['pass'];  
$ldapdomain = $_POST['dominio'];


$ldapconn = ldap_connect($ldapdomain)
    or die("Could not connect to LDAP server.");




if ($ldapconn) 
{    
	$ldapbind = ldap_bind($ldapconn, $user, $ldappass);

    if ($ldapbind) 
	{
		$dn = "CN=Users,DC=arias,DC=com";
		
		$filter="(sAMAccountName=".$_POST['user'].")";
		$justthese = array("ou", "sn", "givenname", "displayname");
		$sr=ldap_search($ldapconn, $dn, $filter, $justthese);
		$info = ldap_get_entries($ldapconn, $sr);
		$nombre = $info[0]["givenname"][0];
		$apellido = $info[0]["sn"][0];
		$display = $info[0]["displayname"][0];
		
		
	} 	
    else 
	{
		echo"<script> alert('Usuario o clave incorrecta. Vuelva a intentar por favor.'); 		
		window.location.href='index.html'; </script>"; 
	}

}
}
else
{
	echo"<script> alert('Por favor llene todos los campos.'); 		
		window.location.href='index.html'; </script>"; 
}
?>


<html >
  <head>
    <meta charset="UTF-8">
    <title>Informacion del Usuario</title>
    <link rel="icon" href="http://iconogen.com/images/computer.png">
    
    
    
        <style>
      /* NOTE: The styles were added inline because Prefixfree needs access to your styles and they must be inlined if they are on local disk! */
      @import url("http://fonts.googleapis.com/css?family=Open+Sans:400,600,700");
@import url("http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css");
*, *:before, *:after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body {
  height: 100%;
}

body {
  font: 14px/1 'Open Sans', sans-serif;
  color: #555;
  background: #eee;
}

h1 {
  padding: 50px 0;
  font-weight: 400;
  text-align: center;
}

p {
  margin: 0 0 20px;
  line-height: 1.5;
}

main {
  min-width: 320px;
  max-width: 800px;
  padding: 50px;
  margin: 0 auto;
  background: #fff;
}

section {
  display: none;
  padding: 20px 0 0;
  border-top: 1px solid #ddd;
}

input[type=radio]{ width:0; height:0;}
label {
  display: inline-block;
  margin: 0 0 -1px;
  padding: 15px 25px;
  font-weight: 600;
  text-align: center;
  color: #bbb;
  border: 1px solid transparent;
}

label:before {
  font-family: fontawesome;
  font-weight: normal;
  margin-right: 10px;
}

label[for*='1']:before {
  content: '\f1cb';
}

label[for*='2']:before {
  content: '\f17d';
}

label[for*='3']:before {
  content: '\f16b';
}

label[for*='4']:before {
  content: '\f1a9';
}

label:hover {
  color: #888;
  cursor: pointer;
}

input:checked + label {
  color: #555;
  border: 1px solid #ddd;
  border-top: 2px solid orange;
  border-bottom: 1px solid #fff;
}

#tab1:checked ~ #content1,
#tab2:checked ~ #content2,
#tab3:checked ~ #content3,
#tab4:checked ~ #content4 {
  display: block;
}

@media screen and (max-width: 650px) {
  label {
    font-size: 0;
  }

  label:before {
    margin: 0;
    font-size: 18px;
  }
}
@media screen and (max-width: 400px) {
  label {
    padding: 15px;
  }
}

    </style>

    
        <script src="js/prefixfree.min.js"></script>

    
  </head>

  <body>

    <h1>Bienvenido <?php echo $nombre.' '.$apellido;?> !</h1>

<main>
  
  <input id="tab1" type="radio" name="tabs" checked>
  <label for="tab1">General</label>
    
  <input id="tab2" type="radio" name="tabs">
  <label for="tab2">Member Of</label>
    
  <input id="tab3" type="radio" name="tabs">
  <label for="tab3">Cambio de password</label>

 <input id="tab4" type="radio" name="tabs">
  <label for="tab4">Cerrar sesion</label>


  
    
<section id="content1"> 
<link rel="stylesheet" type="text/css" href="css\tabla.css">
<table class="table-fill">
<thead>
<tr>
<th class="text-center">First Name</th>
<th class="text-center">Last Name</th>
<th class="text-center">Display Name</th>
</tr>
</thead>
<tr>
<td class="text-center"><?php echo $nombre; ?></td>
<td class="text-center"><?php echo $apellido;?></td>
<td class="text-center"><?php echo $display;?></td>
</tr>
</tbody>
</table>
</section>
    
 <section id="content2">
<link rel="stylesheet" type="text/css" href="css\tabla.css">
<table class="table-fill" id="tablaGrupos">
<thead>
<th class="text-center">Grupos</th>
</thead>
</tbody>
</table>  

  </section>
    
<section id="content3">

<link rel="stylesheet" type="text/css" href="css\password.css">
<div class="container">

    <form id="signup" action = "https://52.38.28.35">

        
        
        <div class="sep"></div>

        <div class="inputs">
        
            
            
            <button class="button button5">Cambiar password</button>
        
        </div>

    </form>

</div>
</section>
    

<section id="content4">

<link rel="stylesheet" type="text/css" href="css\password.css">
<div class="container">

    <form " action = "index.html">

        
        
        <div class="sep"></div>

        <div class="inputs">
        
            
            
            
            
            <button class="button button5">Cerrar Sesion</button>
        
        </div>

    </form>

</div>
</section>





</main>
</body>


<script>

function myFunction(grupo) 
{
    var table = document.getElementById("tablaGrupos");
    var row = table.insertRow(1);
    var cell1 = row.insertCell(0);
    cell1.innerHTML = grupo;
   
}

<?php

$y = 0;
$results = ldap_search($ldapconn, $dn,"(samaccountname=".$ldaprdn.")",array("memberof"));
$entries = ldap_get_entries($ldapconn, $results);
	
$output = $entries[0]['memberof'];

foreach($output as $a) 
{
	if($y!==0)
{
	$r = explode(",",$a,2);
	$g = explode("=",$r[0]);
	echo "myFunction('$g[1]');";
}
else $y++;
}

?>



</script>


</html>


























































