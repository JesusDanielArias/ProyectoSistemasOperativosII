<?php

if(!empty($_POST['adminuser']) && !empty($_POST['adminpassword']))
{
	$admin  = $_POST['adminuser'];     
	$adminpassword = $_POST['adminpassword'];  

$ldapconn = ldap_connect('arias.com')
    or die("Could not connect to LDAP server.");

	if ($ldapconn) 
	{	    
		$ldapbind = ldap_bind($ldapconn, $admin.'@arias.com', $adminpassword);
	
		if ($ldapbind) 
		{
			
		
			

	
		} 	
    else 
	{
		echo"<script> alert('Usuario o clave incorrecta. Vuelva a intentar por favor.'); 		
		window.location.href='index.html'; </script>"; 
	}

	}
}

else
{
	echo"<script> alert('Por favor llene todos los campos.'); 		
		window.location.href='index.html'; </script>"; 
}
?>













<html >
  <head>
    <meta charset="UTF-8">
    <title>Informacion del Usuario</title>
    
    <link rel="icon" href="http://iconogen.com/images/computer.png">
    
    
        <style>
      /* NOTE: The styles were added inline because Prefixfree needs access to your styles and they must be inlined if they are on local disk! */
      @import url("http://fonts.googleapis.com/css?family=Open+Sans:400,600,700");
@import url("http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.css");
*, *:before, *:after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body {
  height: 100%;
}

body {
  font: 14px/1 'Open Sans', sans-serif;
  color: #555;
  background: #eee;
}

h1 {
  padding: 50px 0;
  font-weight: 400;
  text-align: center;
}

p {
  margin: 0 0 20px;
  line-height: 1.5;
}

main {
  min-width: 320px;
  max-width: 800px;
  padding: 50px;
  margin: 0 auto;
  background: #fff;
}

section {
  display: none;
  padding: 20px 0 0;
  border-top: 1px solid #ddd;
}

input[type=radio]{ width:0; height:0;}
label {
  display: inline-block;
  margin: 0 0 -1px;
  padding: 15px 25px;
  font-weight: 600;
  text-align: center;
  color: #bbb;
  border: 1px solid transparent;
}

label:before {
  font-family: fontawesome;
  font-weight: normal;
  margin-right: 10px;
}

label[for*='1']:before {
  content: '\f1cb';
}

label[for*='2']:before {
  content: '\f17d';
}

label[for*='3']:before {
  content: '\f16b';
}

label[for*='4']:before {
  content: '\f1a9';
}

label:hover {
  color: #888;
  cursor: pointer;
}

input:checked + label {
  color: #555;
  border: 1px solid #ddd;
  border-top: 2px solid orange;
  border-bottom: 1px solid #fff;
}

#tab1:checked ~ #content1,
#tab2:checked ~ #content2,
#tab3:checked ~ #content3,
#tab4:checked ~ #content4 {
  display: block;
}

@media screen and (max-width: 650px) {
  label {
    font-size: 0;
  }

  label:before {
    margin: 0;
    font-size: 18px;
  }
}
@media screen and (max-width: 400px) {
  label {
    padding: 15px;
  }
}

    </style>

    
        <script src="js/prefixfree.min.js"></script>

    
  </head>

  <body>

    <h1>Informacion del Usuario</h1>

<main>
  
  <input id="tab1" type="radio" name="tabs" checked>
  <label for="tab1">General</label>
    
  

    
  <input id="tab3" type="radio" name="tabs">
  <label for="tab3">Cambio de password</label>

 <input id="tab4" type="radio" name="tabs">
  <label for="tab4">Cerrar sesion</label>


  
    
<section id="content1"> 
<link rel="stylesheet" type="text/css" href="css\tabla.css">
<table class="table-fill" id="tablaGrupos">
<thead>
<tr>
<th class="text-center">First Name</th>
<th class="text-center">Last Name</th>
<th class="text-center">Display Name</th>
<th class="text-center">Grupos</th>
</tr>
</thead>
</tbody>
</table>
</section>
    
 
    
<section id="content3">

<link rel="stylesheet" type="text/css" href="css\password.css">
<div class="container">

    <form id="signup" action = "https://52.38.28.35">

        
        
        <div class="sep"></div>

        <div class="inputs">
        
            
            
            <button class="button button5">Cambiar password</button>
        
        </div>

    </form>

</div>
</section>
    

<section id="content4">

<link rel="stylesheet" type="text/css" href="css\password.css">
<div class="container">

    <form " action = "index.html">

        
        
        <div class="sep"></div>

        <div class="inputs">
        
            
            
            
            
            <button class="button button5">Cerrar Sesion</button>
        
        </div>

    </form>

</div>
</section>





</main>
</body>


<script>

function myFunction(nombre, apellido, display) 
{
    var table = document.getElementById("tablaGrupos");
    var row = table.insertRow(1);
    var cell1 = row.insertCell(0);
var cell2 = row.insertCell(1);
var cell3 = row.insertCell(2);
var cell4 = row.insertCell(3);
    cell1.innerHTML = nombre;
cell2.innerHTML = apellido;
cell3.innerHTML = display;
cell4.innerHTML = "Grupos: ";
   
}

function myFunction2(grupo) 
{
    var table = document.getElementById("tablaGrupos");
    var row = table.insertRow(1);
    
var cell1 = row.insertCell(0);
var cell2 = row.insertCell(1);
var cell3 = row.insertCell(2);
var cell4 = row.insertCell(3);
    cell1.innerHTML = "";
cell2.innerHTML = "";
cell3.innerHTML = "";
cell4.innerHTML = grupo;

   
}


<?php

$x = 1;
$y = 1;

 $ldap_base_dn = 'CN=Users, DC=arias,DC=com';
   $search_filter = '(givenname=*)';
    $attributes = array();
    $attributes[] = 'givenname';
    $attributes[] = 'sn';
    $attributes[] = 'displayname';
    $result = ldap_search($ldapconn, $ldap_base_dn, $search_filter, $attributes);
    if (FALSE !== $result)
{
        $entries = ldap_get_entries($ldapconn, $result);
	


foreach($entries as $a) 
{
	

$nombre = $a['givenname'][0];
$apellido = $a['sn'][0];
$display = $a['displayname'][0];


	

$results = ldap_search($ldapconn, $ldap_base_dn,"(givenname=".$nombre.")",array("memberof"));
$entries2 = ldap_get_entries($ldapconn, $results);
	
$output = $entries2[0]['memberof'];

foreach($output as $a) 
{
	if($y!==1)
{
	$r = explode(",",$a,2);
	$g = explode("=",$r[0]);
	echo "myFunction2('$g[1]');";
}
$y++;
}

if($x!==1)
{
	echo "myFunction('$nombre','$apellido','$display');";
}

$x++;
}
}
?>


</script>


</html>














































































































